Name: Thomas Jeffries
CSC172 lab15
No partner

This goal of this lab was to implement a basic backtracking algorithm with the purpose of solving the 
"making change" problem. There is only one file in my implementation, which contains the basic input 
code and the backtracking algorithm and helper method. The algorithm works very similarly to the way 
described in the prework file.  
