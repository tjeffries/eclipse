/* Author: Thomas Jeffries
 * Test class for Point Location
 * */
public class PLTest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
	}
}
