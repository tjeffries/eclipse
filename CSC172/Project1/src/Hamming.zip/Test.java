public class Test {

	public static void main(String[] args){
		Hamming.encode_7_4("C:/Users/thomas/workspace/Hamming/sample.txt", "output.txt");
		Hamming.decode_7_4("C:/Users/thomas/workspace/Hamming/sample.txt", "output.txt");
	}																					
}
