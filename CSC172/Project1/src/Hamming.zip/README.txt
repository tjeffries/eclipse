Name: Thomas Jeffries
CSC172 Project 1, Hamming codes

I ran out of time on this project (should have started earlier). I've decided to turn in what I've got rather than to continue to lose points for being later. 
Currently file reading and 7_4 encoding are complete and functional. Decoding is outlined but exhibits some error.