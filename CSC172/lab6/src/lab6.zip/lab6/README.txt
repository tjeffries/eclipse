Name: Thomas Jeffries
No partner
Lab 6, CSC172

This linked stack implementation is very simple and requires virtually no clarification/explanation. 
Output files are in output.txt, copied from console.