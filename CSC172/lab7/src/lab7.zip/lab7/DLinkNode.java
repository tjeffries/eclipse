package lab7;

public class DLinkNode <AnyType> {
	AnyType data;
	DLinkNode<AnyType> next;
	DLinkNode<AnyType> last;
}
