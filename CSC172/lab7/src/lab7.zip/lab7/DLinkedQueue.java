/* Author: Thomas Jeffries
 * This is a simple doubly-linked queue implementation.
 * */
package lab7;

public class DLinkedQueue<AnyType> {
	
	private DLinkNode<AnyType> head, tail;
	
	public DLinkedQueue(){
		head = tail = null;
	}
	
	//appends node to end of queue
	public void enqueue(AnyType x){
		try{
			System.out.println("attempting to add element");
			DLinkNode<AnyType> tmp = new DLinkNode<AnyType>();
			tmp.data = x;
	System.out.println("attempting to add element");
			if(isEmpty()){
				head = tmp;
				tail = tmp;
				return;
			}
			System.out.println("added element");
					tmp.last = tail;
					tmp.next = null;
					tail.next = tmp;
					tail = tmp;
		} catch(Exception e) {
			e.printStackTrace();
		}
			
	}
	
	public AnyType dequeue(){
		if(isEmpty())
			return null;
		AnyType tmp = head.data;
		head = head.next;
		if(head != null)
			head.last = null;
		return tmp;
	}
	
	public AnyType peek(){
		if(isEmpty())
			return null;
		return head.data;
	}
	
	public boolean isEmpty(){
		if(head == null)
			return true;
		return false;
	}
	
	public void printQueue(){
		String s = "";
		DLinkNode<AnyType> n = head;
		while(n != null){
			s += n.data.toString()+" ";
			n = n.next;
		}
		System.out.println(s);
	}
}
