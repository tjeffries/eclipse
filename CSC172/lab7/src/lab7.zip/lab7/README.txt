Name: Thomas Jeffries
No partner
Lab 7, CSC172

This doubly-linked queue implementation is very simple and requires virtually no clarification/explanation.
Rather than using the previously created linked list, I transferred code form that class and made a clean
doubly linked list implementation.