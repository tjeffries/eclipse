package lab13;

public interface AdjList {
	int begin();
	int next();
	boolean end();
}
