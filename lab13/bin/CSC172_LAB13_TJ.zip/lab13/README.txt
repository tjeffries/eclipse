Name: Thomas Jeffries
tjeffri2@u.rochester.edu
No partner
Lab 12, CSC172

In this lab I implemented a simple adjacency matrix for tracking graph vertices and edges, as well as an 
iterator inner class to navigate through the contents of the adjacency matrix. The Graph class contains 
the adjacency matrix data structure, as well as housing an inner iterator class ("AdjArray") that implements the 
interface called AdjList. The Edge class is used as a wrapper for edges between vertices, and contains 
the vertex numbers of the two end points of the edge described by the object.