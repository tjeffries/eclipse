package project4;

public interface AdjList {
	int begin();
	int next();
	boolean end();
}
