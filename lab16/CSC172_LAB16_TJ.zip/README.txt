Author: Thomas Jeffries
Lab 16
no partner

This lab is intended to demonstrate basic understanding a capability dealing with pointers in c. 
The file llist.c contains all the functions as well as the main function for this lab. The 
programming environment used was gcc on Windows 10 Ubuntu bash.