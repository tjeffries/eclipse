Name: Thomas Jeffries
tjeffri2@u.rochester.edu
No partner
Lab 8, CSC172

This is a generic binary tree implementation that stores objects which extend the Comparable interface.
MyTreeNode is the implementation of the Node object, with all lookup/delete/insert/print functions
defined recursively within it. BSTree is the object representing the tree, and BSTTest contains a
main method with test functions and printouts.