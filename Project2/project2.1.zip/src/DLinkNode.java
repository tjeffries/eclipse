

public class DLinkNode <AnyType> {
	AnyType data;
	DLinkNode<AnyType> next;
	DLinkNode<AnyType> last;
}
